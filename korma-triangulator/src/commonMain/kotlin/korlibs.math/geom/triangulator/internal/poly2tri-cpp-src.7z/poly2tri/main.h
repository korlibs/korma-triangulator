//
// Created by Carlos Ballesteros Velasco on 13/7/23.
//

#ifndef POLY2TRI_MAIN_H
#define POLY2TRI_MAIN_H

class main {};

#endif // POLY2TRI_MAIN_H
