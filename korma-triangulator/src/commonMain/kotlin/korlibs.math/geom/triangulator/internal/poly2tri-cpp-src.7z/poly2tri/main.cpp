//
// Created by Carlos Ballesteros Velasco on 13/7/23.
//

#include <cstdio>
#include <iostream>
#include "main.h"
#include "sweep/cdt.h"

int main() {
  std::vector<p2t::Point*> empty;

  // Define the square vertices
  std::vector<p2t::Point*> polyline;
  polyline.push_back(new p2t::Point(0, 130));
  polyline.push_back(new p2t::Point(-270, 0));
  polyline.push_back(new p2t::Point(130, -40));
  polyline.push_back(new p2t::Point(10, -60));
  polyline.push_back(new p2t::Point(-10, -20));
  polyline.push_back(new p2t::Point(100, 30));
  polyline.push_back(new p2t::Point(40, -40));
/*
  polyline.push_back(new p2t::Point(0, 0));
  polyline.push_back(new p2t::Point(0, 100));
  polyline.push_back(new p2t::Point(100, 100));
  polyline.push_back(new p2t::Point(100, 0));

  std::vector<p2t::Point*> polyline2;
  polyline2.push_back(new p2t::Point(40, 40));
  polyline2.push_back(new p2t::Point(40, 60));
  polyline2.push_back(new p2t::Point(60, 40));
*/
  // Create a CDT object (Constrained Delaunay Triangulation)
  p2t::CDT cdt(polyline);
  //cdt.AddHole(polyline, true);
  //cdt.AddHole(polyline2, false);

  // Perform triangulation
  cdt.Triangulate();

  // Get triangles
  std::vector<p2t::Triangle*> triangles;
  triangles = cdt.GetTriangles();

  // Output the results
  for (auto *triangle : triangles) {
    for (int i = 0; i < 3; i++) {
      std::cout << "(" << triangle->GetPoint(i)->x << ", " << triangle->GetPoint(i)->y << ") ";
    }
    std::cout << std::endl;
  }

  // Clean up allocated memory
  for (auto *p : polyline) {
    delete p;
  }
  printf("HELLO!\n");
  return 0;
}